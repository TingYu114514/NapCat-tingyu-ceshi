// 听雨独立查询插件 - 1:1 复刻听雨API架构风格
import * as fs from 'node:fs';
import * as path from 'node:path';

const EventType = { MESSAGE: "message" };

let startTime = Date.now();
let logger = null;
let plugin_config_ui = []; // 全局变量定义

// --- 核心配置 ---
let currentConfig = {
  enableQQ: true,
  enableGroup: true,
  apiTimeout: 15000,
  qqApiUrl: "https://api.yeyuannb.xyz/QQ/api.php",
  groupApiUrl: "https://uapis.cn/api/v1/social/qq/groupinfo",
  qqResultTitle: "听雨 · QQ详细资料",
  groupResultTitle: "听雨 · Q群详细资料",
  separatorText: "------------",
  aboutLink: "https://github.com/TingYu114514/NapCat-tingyu-ceshi", // 插件介绍链接
  defaultUA: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
};

// --- 工具函数 ---
function buildTipText(title, content) {
  return `${title}\n${currentConfig.separatorText}\n${content}`;
}

function giveText(message) {
  if (!Array.isArray(message)) return "";
  return message.filter(s => s.type === "text").map(s => s.data?.text || "").join("").trim();
}

async function sendReply(event, content, ctx) {
  if (!ctx.actions || !content) return;
  const params = {
    message: content,
    message_type: event.message_type,
    ...event.message_type === "group" ? { group_id: String(event.group_id) } : { user_id: String(event.user_id) }
  };
  try {
    await ctx.actions.call("send_msg", params, ctx.adapterName, ctx.pluginManager.config);
  } catch (error) {
    logger?.error("【查询助手】发送失败:", error);
  }
}

// --- 核心查询逻辑 ---
async function performQQQuery(targetQQ, event, ctx) {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), currentConfig.apiTimeout);
    const res = await fetch(`${currentConfig.qqApiUrl}?qq=${targetQQ}`, { 
      signal: controller.signal,
      headers: { "User-Agent": currentConfig.defaultUA } 
    });
    clearTimeout(timeoutId);
    const data = await res.json();
    if (!data || !data.nickname) throw new Error("No data");

    const content = [
      `[CQ:image,file=${data.avatar_url}]`, // 头像信息一体
      `👤 昵称：${data.nickname}`,
      `🔢 QQ号：${data.qq}`,
      `✨ 等级：${data.qq_level || 0}级`,
      `💎 身份：${data.is_vip ? '⭐ SVIP' : '普通用户'}`,
      `📅 注册：${data.reg_time ? data.reg_time.split('T')[0] : "未知"}`,
      `📝 签名：${data.long_nick || "暂无签名"}`
    ].join("\n");
    await sendReply(event, buildTipText(currentConfig.qqResultTitle, content), ctx);
  } catch (e) { await sendReply(event, "❌ 查询失败，接口超时", ctx); }
}

async function performGroupQuery(groupId, event, ctx) {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), currentConfig.apiTimeout);
    const res = await fetch(`${currentConfig.groupApiUrl}?group_id=${groupId}`, { 
      signal: controller.signal, 
      headers: { "User-Agent": currentConfig.defaultUA }
    });
    clearTimeout(timeoutId);
    const data = await res.json();
    if (!data || !data.group_name) throw new Error("No data");

    const content = [
      `[CQ:image,file=${data.avatar_url}]`,
      `📢 群名：${data.group_name}`,
      `🔢 群号：${data.group_id}`,
      `👑 群主：${data.owner_uin || "未知"}`,
      `📊 成员：${data.member_count}/${data.max_member_count}`,
      `📅 建群：${data.create_time_str || "未知"}`,
      `📝 简介：${data.description || "暂无简介"}`
    ].join("\n");
    await sendReply(event, buildTipText(currentConfig.groupResultTitle, content), ctx);
  } catch (e) { await sendReply(event, "❌ 群查询失败", ctx); }
}

// --- 1:1 复刻的可视化配置构造函数 ---
function initConfigUI(ctx) {
  if (!ctx.NapCatConfig || typeof ctx.NapCatConfig.combine !== "function") return [];
  const configList = [];

  // 【介绍卡片】 标题：关于插件 内容：介绍
  if (typeof ctx.NapCatConfig.html === "function") {
    configList.push(
      ctx.NapCatConfig.html(`
        <div style="padding: 12px; background: rgba(0,122,255,0.05); border-radius: 8px; border: 1px solid rgba(0,122,255,0.1); margin-bottom: 10px;">
          <h3 style="margin: 0; color: #007aff;">关于插件</h3>
          <p style="margin: 5px 0 0; color: #666; font-size: 14px;">
            听雨独立查询助手：提供稳定高效的 QQ 与 Q群 信息查询服务。<br>
            插件开源链接：${currentConfig.aboutLink}
          </p>
        </div>
      `)
    );
  }

  if (typeof ctx.NapCatConfig.html === "function") {
    configList.push(ctx.NapCatConfig.html('<div style="margin: 15px 0 8px; font-weight: 600;">功能开关</div>'));
  }

  if (typeof ctx.NapCatConfig.boolean === "function") {
    configList.push(
      ctx.NapCatConfig.boolean("enableQQ", "开启QQ查询功能", currentConfig.enableQQ, "开启后响应查询QQ指令"),
      ctx.NapCatConfig.boolean("enableGroup", "开启Q群查询功能", currentConfig.enableGroup, "开启后响应Q群查询指令")
    );
  }

  if (typeof ctx.NapCatConfig.html === "function") {
    configList.push(ctx.NapCatConfig.html('<div style="margin: 20px 0 8px; font-weight: 600;">内容配置</div>'));
  }

  if (typeof ctx.NapCatConfig.text === "function") {
    configList.push(
      ctx.NapCatConfig.text("aboutLink", "插件开源链接", currentConfig.aboutLink, "修改介绍卡片显示的链接"),
      ctx.NapCatConfig.text("qqResultTitle", "个人查询标题", currentConfig.qqResultTitle, "修改查询结果顶部的标题"),
      ctx.NapCatConfig.text("groupResultTitle", "Q群查询标题", currentConfig.groupResultTitle, "修改群查询结果顶部的标题"),
      ctx.NapCatConfig.text("separatorText", "分割线样式", currentConfig.separatorText)
    );
  }

  try {
    return ctx.NapCatConfig.combine(...configList);
  } catch (e) {
    return [];
  }
}

// --- 插件生命周期 ---
export async function plugin_init(ctx) {
  logger = ctx.logger || console;
  
  if (ctx.configPath && fs.existsSync(ctx.configPath)) {
    try {
      currentConfig = Object.assign(currentConfig, JSON.parse(fs.readFileSync(ctx.configPath, "utf-8")));
    } catch (e) { logger.error("加载配置文件失败"); }
  }

  // 1:1 复刻：在初始化时为全局变量赋值
  plugin_config_ui = initConfigUI(ctx);
  logger.info("【听雨独立查询】初始化完成！");
}

export async function plugin_onmessage(ctx, event) {
  if (event.post_type !== EventType.MESSAGE) return;
  const rawMsg = giveText(event.message);

  if (currentConfig.enableQQ && (rawMsg.startsWith("QQ查询") || rawMsg.startsWith("查询QQ") || rawMsg === "我的QQ信息")) {
    const target = rawMsg === "我的QQ信息" ? String(event.user_id) : rawMsg.replace(/^(QQ查询|查询QQ)/, "").trim();
    if (/^\d{5,13}$/.test(target)) return await performQQQuery(target, event, ctx);
  }

  if (currentConfig.enableGroup && (rawMsg.startsWith("Q群查询") || rawMsg.startsWith("群查询"))) {
    const target = rawMsg.replace(/^(Q群查询|群查询)/, "").trim();
    if (/^\d{5,13}$/.test(target)) return await performGroupQuery(target, event, ctx);
  }
}

export async function plugin_get_config() { return currentConfig; }

export async function plugin_set_config(ctx, newConfig) {
  currentConfig = Object.assign(currentConfig, newConfig);
  if (ctx.configPath) {
    fs.writeFileSync(ctx.configPath, JSON.stringify(currentConfig, null, 2));
  }
}

// 统一导出变量
export { plugin_config_ui };
